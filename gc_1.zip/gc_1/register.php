<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Green Credit Management by CodeCatalyst</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
                body {
            background-image: url('https://images.unsplash.com/photo-1483794344563-d27a8d18014e?fm=jpg&w=3000&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGdyZWVuJTIwcGxhbnRzJTIwYmFja2dyb3VuZHxlbnwwfHwwfHx8MA%3D%3D');
            background-size: cover;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items:center;
            height: 100vh;
            margin: 0;
            font-family: 'Roboto', sans-serif;
        }
        </style>
</head>
<body>
    <div class="container">
        <h1>Register</h1>
        <p>Please select your registration type:</p>
        <div class="buttons">
            <a href="register_applier.php" class="button">Apply for GC</a>
            <a href="register_buyer.php" class="button">Buy GC</a>
        </div>
    </div>
</body>
</html>