<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'gc_applier') {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Logic to handle withdrawal request, e.g., updating the wallet balance and sending an email for manual processing
    $message = "Withdrawal request under process.";
    header("Location: trade_applier.php?message=" . urlencode($message));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw - Green Credit Management by CodeCatalyst</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
                body {
            background-image: url('https://media.istockphoto.com/id/1198334973/vector/falling-american-dollar-bills-seamless-pattern-on-white-background.jpg?s=612x612&w=0&k=20&c=YmRnfuNww1Mn6Ezy7_sWWJHx113BfDxsDWyRaVMhAN0=');
            background-size: cover;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items:center;
            height: 100vh;
            margin: 0;
            font-family: 'Roboto', sans-serif;
        }
        </style>
</head>
<body>
    <div class="container">
        <h1>Withdraw Money</h1>
        <p>Click the button below to request a withdrawal.</p>
        <form method="post" action="withdraw.php">
            <button type="submit">Request Withdrawal</button>
        </form>
    </div>
</body>
</html>