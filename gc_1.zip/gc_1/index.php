<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green Credit Management by Code Catalyst</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

        body {
            font-family: 'Roboto', Arial, sans-serif;
            background: url('https://currentaffairs.adda247.com/wp-content/uploads/multisite/sites/5/2023/10/16083857/1_bVM9Tl6tPhfZ2nmKfaB-0A.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #fff;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: space-between;
        }

        .header, .footer {
            background-color: #28a745;
            padding: 20px;
            text-align: center;
            color: #fff;
            width: 100%;
            position: fixed;
            left: 0;
            z-index: 1000;
        }

        .header {
            top: 0;
        }

        .footer {
            bottom: 0;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            padding: 20px;
            margin: auto;
            text-align: center;
            color: #333;
            backdrop-filter: blur(10px);
        }

        .container h1 {
            margin-bottom: 20px;
            color: #fff;
            font-weight: 700;
        }

        .container p {
            color: #fff;
            font-weight: 400;
        }

        .buttons {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }

        .button {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
            display: inline-block;
            transition: background-color 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-weight: 700;
        }

        .button:hover {
            background-color: #0056b3;
        }

        main {
            display: flex;
            flex: 1;
            align-items: center;
            justify-content: center;
        }
        img{
            align: left;
        }
    </style>
</head>
<body>

    

    <div class="header">
    <img src="https://media.istockphoto.com/id/1045368942/vector/abstract-green-leaf-logo-icon-vector-design-ecology-icon-set-eco-icon.jpg?s=612x612&w=0&k=20&c=XIfHMI8r1G73blCpCBFmLIxCtOLx8qX0O3mZC9csRLs="
      width="55" height="55" alt="logo">
        <h1>Welcome to Green Credit Management</h1>
    </div> 
    <main>
        <div class="container">
            <h1>Welcome to Green Credit Management by Code Catalyst</h1>
            <p>This platform helps manage and trade green credits efficiently. Whether you're looking to apply for green credits or buy them, we've got you covered.</p>
            <div class="buttons">
                <a href="register.php" class="button">Register</a>
                <a href="login.php" class="button">Login</a>
            </div>
        </div>
    </main>
    <div class="footer">
        <p>&copy; 2024 Green Credit Management</p>
        <span>Call Us!</span>
                                <span class="phone_no">
                                     9350878562 7879515401 
                                </span>
    </div>
</body>
</html>





