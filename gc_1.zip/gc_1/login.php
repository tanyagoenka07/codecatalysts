<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare the statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, password, user_type, city, wallet FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($user_id, $hashed_password, $user_type, $city, $wallet);
    $stmt->fetch();
    $stmt->close();

    // Verify the password
    if (password_verify($password, $hashed_password)) {
        session_start();
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $username;
        $_SESSION['user_type'] = $user_type;
        $_SESSION['city'] = $city;

        // Set default wallet balance if it's zero
        if ($wallet == 0) {
            $wallet = 10000;
            $stmt = $conn->prepare("UPDATE users SET wallet = ? WHERE id = ?");
            $stmt->bind_param("di", $wallet, $user_id);
            $stmt->execute();
            $stmt->close();
        }

        // Redirect based on user type
        if ($user_type == 'gc_applier') {
            header("Location: trade_applier.php");
        } else {
            header("Location: trade_buyer.php");
        }
        exit();
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Green Credit Management by Code Catalyst</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

        body {
            font-family: 'Roboto', Arial, sans-serif;
            background: url('https://images.rawpixel.com/image_social_landscape/czNmcy1wcml2YXRlL3Jhd3BpeGVsX2ltYWdlcy93ZWJzaXRlX2NvbnRlbnQvbHIvdjk4Ni1iZy0wMi1rcWhlM3dpdC5qcGc.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            color: #fff;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: center;
            align-items: center;
        }

        .header {
            background-color: rgba(40, 167, 69, 0.9);
            width: 100%;
            text-align: center;
            padding: 20px 0;
            color: #fff;
            position: fixed;
            top: 0;
            z-index: 1000;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            padding: 20px;
            margin: 100px auto 0 auto;
            text-align: center;
            color: #333;
            backdrop-filter: blur(10px);
        }

        .container h1 {
            margin-bottom: 20px;
            color: #28a745;
            font-weight: 700;
        }

        .container form {
            display: flex;
            flex-direction: column;
        }

        .container input[type="text"],
        .container input[type="password"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }

        .container input[type="submit"] {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .container input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 20px;
        }

        .footer {
            background-color: rgba(40, 167, 69, 0.9);
            width: 100%;
            text-align: center;
            padding: 10px 0;
            color: #fff;
            position: fixed;
            bottom: 0;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Green Credit Management</h1>
    </div>
    <div class="container">
        <h1>Login</h1>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="" method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Login">
        </form>
    </div>
    <div class="footer">
        <p>&copy; 2024 Green Credit Management</p>
        <span>Call Us!</span>
                                <span class="phone_no">
                                     9350878562  7879515401
                                </span>
    </div>
</body>
</html>