<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'gc_applier') {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Logic to handle verification request, e.g., sending an email to admin for manual verification
    $message = "Verification request sent.";
    header("Location: trade_applier.php?message=" . urlencode($message));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verification - Green Credit Management by CodeCatalyst</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
                body {
            background-image: url('https://img.freepik.com/premium-photo/green-check-mark-icon-podium-against-green-background-check-mark-is-symbol-approval-success-completion_14117-122973.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items:center;
            height: 100vh;
            margin: 0;
            font-family: 'Roboto', sans-serif;
        }
        p{
            font-size: 10px;
        }
        </style>
</head>
<body>
    <div class="container">
        <h1>Verification</h1>

        <p > The administrator grants a certificate of Green Credit based on the agency's report. The calculation considers factors such as resource requirements, scale, scope, and size. For example, one green credit is given for each tree grown on a land parcel that meets certain criteria:
The land parcel is at least five hectares in size.
It has a minimum density of 1,100 trees per hectare.
It's free from encumbrances.
It's based on local soil conditions, silvi-climatic conditions, and certification of completion.</p>
<h6>Click the button below to send a verification request.</h6>
        <form method="post" action="verify.php">
            <button type="submit">Send Verification Request</button>

        </form>
    </div>
</body>
</html>